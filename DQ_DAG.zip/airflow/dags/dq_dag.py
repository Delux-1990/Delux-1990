import os
from datetime import datetime
from airflow.models.dag import DAG
from airflow.utils.task_group import TaskGroup
from airflow.operators.dummy import DummyOperator
from airflow.providers.postgres.operators.postgres import PostgresOperator
from dq_plugin.operators.load_task_operator import LoadTaskOperator
from dq_plugin.operators.check_task_availability_operator import CheckTaskAvailabilityOperator
from dq_plugin.operators.collect_inputs_operator import CollectInputsOperator
from dq_plugin.operators.prepare_data.check_daterange_operator import CheckDaterangeOperator
from dq_plugin.operators.prepare_data.get_raw_values_operator import GetRawValuesOperator
from dq_plugin.operators.bad_task_received_operator import BadTaskReceivedOperator
from dq_plugin.operators.apply_data_quality_algorithms.process_data_from_future_operator import ProcessDataFromFutureOperator
from dq_plugin.operators.apply_data_quality_algorithms.process_gaps_operator import ProcessGapsOperator
from dq_plugin.operators.apply_data_quality_algorithms.process_outliers_operator import ProcessOutliersOperator
from dq_plugin.operators.apply_data_quality_algorithms.process_anomalies_operator import ProcessAnomaliesOperator
from dq_plugin.operators.apply_data_quality_algorithms.classify_input_type_operator import ClassifyInputTypeOperator
from dq_plugin.operators.apply_data_quality_algorithms.classify_input_profile_operator import ClassifyInputProfileOperator
from dq_plugin.operators.send_results.check_sending_results_operator import ChooseSendingResultsOperator
from dq_plugin.operators.send_results.send_cleansed_data_operator import SendCleansedDataOperator
from dq_plugin.operators.send_results.send_final_report_operator import SendFinalReportOperator


dag_name = os.path.basename(__file__).split('.')[0].lower()

with DAG(
    dag_id=dag_name,
    description='DQ Analyzing',
    schedule_interval='@hourly',
    start_date=datetime.now(),
    max_active_runs=4,
    catchup=False,
    tags=['dq'],
    default_args={
        'owner': 'ileco.energy',
        'email': ['some@ileco.energy'],
        'email_on_failure': False,
        'email_on_retry': False,
        'retries': 0
    },
    params={
        'connection_id': 'dq_tsdb',
        'local_mode': True
    }
) as dag:
    load_task = LoadTaskOperator(task_id='load_task')

    check_task_availability = CheckTaskAvailabilityOperator(task_id='check_tasks_availability')

    no_task_received = DummyOperator(task_id='no_task_received')

    collect_inputs = CollectInputsOperator(task_id='collect_inputs')

    bad_task_received = BadTaskReceivedOperator(task_id='bad_task_received')

    with TaskGroup(group_id='prepare_data') as prepare_data:
        check_daterange = CheckDaterangeOperator(task_id='check_daterange')

        create_inputs_values_table = PostgresOperator(task_id='create_inputs_values_table',
                                                      postgres_conn_id=dag.params['connection_id'],
                                                      sql='sql/create_inputs_values_table.sql')

        get_raw_values = GetRawValuesOperator(task_id='get_raw_values',
                                              connection_id=dag.params['connection_id'],
                                              table_name='inputs_values')

        check_daterange >> create_inputs_values_table >> get_raw_values

    with TaskGroup(group_id='apply_data_quality_algorithms') as apply_data_quality_algorithms:
        process_data_from_future = ProcessDataFromFutureOperator(task_id='process_data_from_future',
                                                                 connection_id=dag.params['connection_id'],
                                                                 table_name='inputs_values')

        process_gaps = ProcessGapsOperator(task_id='process_gaps',
                                           connection_id=dag.params['connection_id'],
                                           table_name='inputs_values')

        process_outliers = ProcessOutliersOperator(task_id='process_outliers',
                                                   connection_id=dag.params['connection_id'],
                                                   table_name='inputs_values')

        process_anomalies = ProcessAnomaliesOperator(task_id='process_anomalies',
                                                     connection_id=dag.params['connection_id'],
                                                     table_name='inputs_values')

        classify_input_type = ClassifyInputTypeOperator(task_id='classify_input_type',
                                                        connection_id=dag.params['connection_id'],
                                                        table_name='inputs_values')

        classify_input_profile = ClassifyInputProfileOperator(task_id='classify_input_profile',
                                                              connection_id=dag.params['connection_id'],
                                                              table_name='inputs_values')

        process_data_from_future >> process_gaps >> process_outliers >> process_anomalies \
            >> [classify_input_profile, classify_input_type]

    with TaskGroup(group_id='send_results') as send_results:
        choose_sending_results = ChooseSendingResultsOperator(task_id='choose_sending_results')

        send_final_report = SendFinalReportOperator(task_id='send_final_report')

        send_cleansed_data = SendCleansedDataOperator(task_id='send_cleansed_data',
                                                      connection_id=dag.params['connection_id'],
                                                      table_name='inputs_values')

        choose_sending_results >> send_final_report
        choose_sending_results >> send_cleansed_data

    load_task >> check_task_availability
    check_task_availability >> no_task_received
    check_task_availability >> collect_inputs
    collect_inputs >> bad_task_received
    collect_inputs >> prepare_data >> apply_data_quality_algorithms >> send_results
