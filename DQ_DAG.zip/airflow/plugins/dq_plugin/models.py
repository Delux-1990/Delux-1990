from enum import Enum


ACTIONS = {
    'Data from future detection': 'process_data_from_future',
    'Gaps detection': 'process_gaps',
    'Outliers detection': 'process_outliers',
    'Anomalies detection': 'process_anomalies',
    'Input type classifying': 'classify_input_type',
    'Input profile classifying': 'classify_input_profile',
}


ENTITY_NAMES = {
    ACTIONS['Data from future detection']: 'data_from_future',
    ACTIONS['Gaps detection']: 'gaps',
    ACTIONS['Outliers detection']: 'outliers',
    ACTIONS['Anomalies detection']: 'anomalies',
    ACTIONS['Input type classifying']: 'input_type',
    ACTIONS['Input profile classifying']: 'input_profile',
}


INPUT_TYPES = {
    0: 'None',
    1: 'Pulse',
    2: 'Period',
    3: 'Gate',
    4: 'Alarm',
    5: 'MeterReading',
    6: 'Invoice'
}


class ActionStatuses(Enum):
    ISSUES_FOUND = 'Issues found'
    ISSUES_NOT_FOUND = 'Issues not found'
    TYPE_IS_DEFINED = 'Type is defined'
    TYPE_IS_NOT_DEFINED = 'Type is not defined'
    PROFILE_IS_DEFINED = 'Profile is defined'
    PROFILE_IS_NOT_DEFINED = 'Profile is not defined'
    PROCESSING_FAILED = 'Processing failed'
    INPUT_IS_INVALID = 'Input is invalid'


class ValidityStatuses(Enum):
    OK = 'Ok'
    DATERANGE_SHORTENED = 'Daterange is shortened to existing values'
    WRONG_DATERANGE = 'Wrong daterange specified'
    IS_UNREACHABLE = 'Input is unreachable in Value Microservice'
    INTERNAL_ERROR = 'Internal error'
    UNDEFINED = 'Undefined'


class OperatorColors(Enum):
    PROBLEMS_PROCESSING_OPERATOR = '#bbffff'
    CLASSIFIER_OPERATOR = '#ffbbff'
