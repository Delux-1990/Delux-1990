import json
import logging
from typing import Any
from dq_plugin.APIs.dq_service_api import DQServiceAPI
from airflow.models.baseoperator import BaseOperator
import dq_plugin.utils.local_task as local_task
from dq_plugin.models import ACTIONS


logger = logging.getLogger(__name__)


class LoadTaskOperator(BaseOperator):
    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)

    @staticmethod
    def parse_task(api_task: dict):
        """Method serializes dictionary to prepared format"""
        data_source_configuration = {
            'cug_guid': api_task['cug'],
            'buildings_guids': api_task['buildings'],
            'measurements_guids': api_task['measurements'],
            'inputs_guids': api_task['inputs']
        }

        actions_configuration = []
        for action_code in api_task['actions']:
            actions_configuration.append(ACTIONS[action_code])

        daterange_configuration = {
            'timestamp_from': api_task['timestampFrom'],
            'timestamp_to': api_task['timestampTo']
        }

        parsed_task = {
            'id': api_task['id'],
            'to_cleanse': api_task['toCleanse'],
            'endpoint': api_task['endpoint'],
            'data_source_configuration': data_source_configuration,
            'actions_configuration': actions_configuration,
            'daterange_configuration': daterange_configuration
        }

        return parsed_task

    def execute(self, context: Any):
        local_mode = context['dag_run'].conf.get('local_mode', False)

        if local_mode:
            logger.info('Loading local test task')
            task_to_process = local_task.task_to_process
            logger.info(f'Saving task to XCOM:\n{json.dumps(task_to_process, indent=4)}')
            context['ti'].xcom_push(key='task_to_process', value=task_to_process)
        else:
            try:
                logger.info('Loading task from the DQ Microservice')
                api = DQServiceAPI()
                queued_tasks = api.get_tasks_from_queue()

                if queued_tasks:
                    raw_task = queued_tasks[0]

                    logger.info(f"Parsing raw task with id {raw_task['id']}")
                    task_to_process = self.parse_task(raw_task)

                    logger.info('Sending to API status "in process" for received task')
                    api.set_task_to_in_process_status(raw_task['id'])

                    logger.info(f'Saving task to XCOM:\n{json.dumps(task_to_process, indent=4)}')
                    context['ti'].xcom_push(key='task_to_process', value=task_to_process)
                else:
                    logger.info('There are no new tasks in the DQ Microservice')
            except Exception as e:
                logger.error(f'Error during obtaining task: {e}')
