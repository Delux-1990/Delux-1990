import json
import logging
from typing import Any
from airflow.models.baseoperator import BaseOperator
from dq_plugin.APIs.dq_service_api import DQServiceAPI
from dq_plugin.APIs.value_service_api import ValueServiceAPI
from dq_plugin.APIs.cleansed_data_endpoint_api import CleansedDataEndpointApi
from dq_plugin.utils.database_operations import get_input_values_from_db
from dq_plugin.models import ACTIONS
from dq_plugin.models import ActionStatuses


logger = logging.getLogger(__name__)


class SendCleansedDataOperator(BaseOperator):
    def __init__(self, connection_id: str, table_name: str, **kwargs):
        super().__init__(**kwargs)
        self.__connection_id = connection_id
        self.__table_name = table_name

    def execute(self, context: Any):
        inputs: dict = context['ti'].xcom_pull(key='inputs')
        task_to_process = context['ti'].xcom_pull(key='task_to_process')
        task_id = task_to_process['id']
        endpoint = task_to_process['endpoint']

        data_from_future_report = context['ti'].xcom_pull(key=f"{ACTIONS['Data from future detection']}_report")
        gaps_report = context['ti'].xcom_pull(key=f"{ACTIONS['Gaps detection']}_report")
        outliers_report = context['ti'].xcom_pull(key=f"{ACTIONS['Outliers detection']}_report")

        dq_api = DQServiceAPI()
        value_api = ValueServiceAPI()
        endpoint_api = CleansedDataEndpointApi(endpoint)

        logger.info('Sending data of valid cleansed inputs to EcoSCADA database')
        inputs_guids = inputs.keys()
        for input_guid in inputs_guids:
            if inputs[input_guid]['validity']['is_valid']:
                if data_from_future_report[input_guid]['status'] != ActionStatuses.PROCESSING_FAILED.value and \
                        gaps_report[input_guid]['status'] != ActionStatuses.PROCESSING_FAILED.value and \
                        outliers_report[input_guid]['status'] != ActionStatuses.PROCESSING_FAILED.value:
                    building_guid = inputs[input_guid]['building']['guid']
                    for measurement in inputs[input_guid]['measurements']:
                        logger.info(f'Processing input with guid {input_guid}')
                        try:
                            df = get_input_values_from_db(self.__connection_id, self.__table_name, input_guid)
                            dq_api.attach_details_for_task(task_id, df.to_json())
                            fixed_input_guid = dq_api.create_fixed_input(input_guid, measurement['guid'], building_guid)
                            value_api.put_input_values(fixed_input_guid,
                                                       df,
                                                       inputs[input_guid]['properties']['input_type_id'])
                            try:
                                endpoint_api.send_cleansed_data_info(input_guid, fixed_input_guid)
                            except Exception as e:
                                logger.info(f'Error during sending fixed data: {e}')
                        except Exception as e:
                            logger.info(f'Error during preparing fixed data: {e}')
