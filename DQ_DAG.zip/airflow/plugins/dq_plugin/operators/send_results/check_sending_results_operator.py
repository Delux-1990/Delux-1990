import logging
from typing import Any
from airflow.operators.branch import BaseBranchOperator


logger = logging.getLogger(__name__)


class ChooseSendingResultsOperator(BaseBranchOperator):
    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)

    def choose_branch(self, context: Any):
        to_cleanse = context['ti'].xcom_pull(key='task_to_process')['to_cleanse']
        if to_cleanse:
            return ['send_results.send_final_report', 'send_results.send_cleansed_data']
        else:
            return 'send_results.send_final_report'
