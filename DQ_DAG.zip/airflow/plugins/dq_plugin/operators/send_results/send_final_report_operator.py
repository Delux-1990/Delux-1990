import logging
import json
from typing import Any
from airflow.models.baseoperator import BaseOperator
from dq_plugin.utils.database_operations import get_input_values_from_db
from dq_plugin.APIs.dq_service_api import DQServiceAPI
from dq_plugin.APIs.reporting_api import ReportingAPI
from dq_plugin.models import INPUT_TYPES, ENTITY_NAMES, ActionStatuses


logger = logging.getLogger(__name__)


class SendFinalReportOperator(BaseOperator):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def execute(self, context: Any):
        task_to_process = context['ti'].xcom_pull(key='task_to_process')
        inputs: dict = context['ti'].xcom_pull(key='inputs')

        actions_reports = dict()
        for action in task_to_process['actions_configuration']:
            actions_reports[action] = (context['ti'].xcom_pull(key=f'{action}_report'))

        result_info = []
        inputs_guids = inputs.keys()
        for input_guid in inputs_guids:
            input_reports = dict()
            for action in task_to_process['actions_configuration']:
                input_reports[ENTITY_NAMES[action]] = actions_reports[action][input_guid]

            result_info.append(
                {
                    'source': {
                        'cug_name': inputs[input_guid]['cug']['name'],
                        'building_name': inputs[input_guid]['building']['name'],
                        'measurements_names': [measurement['name'] \
                                               for measurement in inputs[input_guid]['measurements']],
                        'input_name': inputs[input_guid]['name']
                    },
                    'properties': {
                        'input_type': INPUT_TYPES[inputs[input_guid]['properties']['input_type_id']],
                        'medium_unit': inputs[input_guid]['properties']['medium_unit'],
                        'gate_time': inputs[input_guid]['properties']['gate_time_name'],
                        'is_forecast': inputs[input_guid]['properties']['is_forecast']
                    },
                    'validity': inputs[input_guid]['validity'],
                    'daterange': inputs[input_guid]['daterange'],
                    'reports': input_reports
                }
            )

        final_report = {
            'original_daterange': task_to_process['daterange_configuration'],
            'reports_configuration': [ENTITY_NAMES[action] for action in task_to_process['actions_configuration']],
            'result_info': result_info
        }

        logger.info(f'Final report:\n{json.dumps(final_report, ensure_ascii=False, indent=4)}')

        dq_api = DQServiceAPI()

        logger.info('Sending final report to Reporting Microservice')
        reporting_api = ReportingAPI()
        try:
            report_guid = reporting_api.create_report(final_report)
            logger.info(f'Report has been created with guid: {report_guid}')
            logger.info('Sending to API status "successed_finished" and attaching report guid to processed task')
            dq_api.attach_report_for_task(task_to_process['id'], report_guid)
            dq_api.set_task_to_successed_finished_status(task_to_process['id'])
        except Exception as e:
            logger.error(f'Error during sending report to Reporting Microservice: {e}')
            logger.info('Sending to API status "sending_failed" for processed task')
            dq_api.set_task_to_failed_status(task_to_process['id'])
