import logging
from typing import Any
from airflow.operators.branch import BaseBranchOperator


logger = logging.getLogger(__name__)


class CheckTaskAvailabilityOperator(BaseBranchOperator):
    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)

    def choose_branch(self, context: Any):
        logger.info(f'Checking XCOM for task')
        task_to_process = context['ti'].xcom_pull(key='task_to_process')

        if task_to_process is not None:
            logger.info('Task was received')
            return 'collect_inputs'
        else:
            logger.info('Task was not received')
            return 'no_task_received'
