import json
import logging
from typing import Any
from airflow.operators.branch import BaseBranchOperator
from dq_plugin.APIs.ecoscada_api import EcoscadaAPI
from dq_plugin.APIs.value_service_api import ValueServiceAPI


logger = logging.getLogger(__name__)


class CollectInputsOperator(BaseBranchOperator):
    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self.__inputs = {}

    def add_input(self, input_info: dict, measurement_info: dict, building_info: dict, cug_info: dict) -> None:
        if input_info['guid'] not in self.__inputs:
            is_forecast = False
            for measurement_property in measurement_info['properties']:
                if measurement_property['code'] == 'IsForecast' and measurement_property['value'] == 'true':
                    is_forecast = True

            self.__inputs[input_info['guid']] = {
                'name': input_info['name'],
                'properties': {
                    'gate_time_interval': input_info['gateTime']['interval'],
                    'gate_time_name': input_info['gateTime']['name'],
                    'medium_unit': input_info['medium']['primaryUnit'],
                    'input_type_id': input_info['inputType'],
                    'is_forecast': is_forecast,
                    'is_meter_bidirectional': input_info['isMeterBidirectional']
                },
                'cug': {
                    'name': cug_info['name'],
                    'guid': cug_info['guid']
                },
                'building': {
                    'name': building_info['name'],
                    'guid': building_info['guid']
                },
                # one input can be linked to many measurements
                'measurements': [
                    {
                        'name': measurement_info['name'],
                        'guid': measurement_info['guid']
                    }
                ]
            }
        else:
            self.__inputs[input_info['guid']]['measurements'].append(
                {
                    'name': measurement_info['name'],
                    'guid': measurement_info['guid']
                }
            )

    def choose_branch(self, context: Any):
        data_source_configuration = context['ti'].xcom_pull(key='task_to_process')['data_source_configuration']

        try:
            logger.info('Collecting inputs for task')
            ecoscada_api = EcoscadaAPI()
            value_api = ValueServiceAPI()

            if data_source_configuration['inputs_guids']:
                cug_info = ecoscada_api.get_cug(data_source_configuration['cug_guid'])
                building_info = ecoscada_api.get_building(data_source_configuration['buildings_guids'][0])
                measurement_info = ecoscada_api.get_measurement(data_source_configuration['measurements_guids'][0])
                for input_guid in data_source_configuration['inputs_guids']:
                    input_info = ecoscada_api.get_input(input_guid)
                    self.add_input(input_info, measurement_info, building_info, cug_info)
            else:
                if data_source_configuration['measurements_guids']:
                    cug_info = ecoscada_api.get_cug(data_source_configuration['cug_guid'])
                    building_info = ecoscada_api.get_building(data_source_configuration['buildings_guids'][0])
                    for measurement_guid in data_source_configuration['measurements_guids']:
                        measurement_info = ecoscada_api.get_measurement(measurement_guid)
                        if measurement_info['formula']:
                            for input_guid in value_api.get_inputs_by_formula(measurement_guid):
                                input_info = ecoscada_api.get_input(input_guid)
                                self.add_input(input_info, measurement_info, building_info, cug_info)
                        else:
                            for input_guid in ecoscada_api.get_all_inputs_guids_in_measurement(measurement_guid):
                                input_info = ecoscada_api.get_input(input_guid)
                                self.add_input(input_info, measurement_info, building_info, cug_info)
                else:
                    if data_source_configuration['buildings_guids']:
                        buildings_guids = data_source_configuration['buildings_guids']
                    else:
                        buildings_guids = ecoscada_api.get_all_buildings_guids_in_cug(data_source_configuration['cug_guid'])

                    cug_info = ecoscada_api.get_cug(data_source_configuration['cug_guid'])
                    for building_guid in buildings_guids:
                        building_info = ecoscada_api.get_building(building_guid)
                        for measurement_guid in ecoscada_api.get_all_measurements_guids_in_building(building_guid):
                            measurement_info = ecoscada_api.get_measurement(measurement_guid)
                            if measurement_info['formula']:
                                for input_guid in value_api.get_inputs_by_formula(measurement_guid):
                                    input_info = ecoscada_api.get_input(input_guid)
                                    self.add_input(input_info, measurement_info, building_info, cug_info)
                            else:
                                for input_guid in ecoscada_api.get_all_inputs_guids_in_measurement(measurement_guid):
                                    input_info = ecoscada_api.get_input(input_guid)
                                    self.add_input(input_info, measurement_info, building_info, cug_info)

            logger.info(f'Saving collected inputs to XCOM:\n{json.dumps(self.__inputs, ensure_ascii=False, indent=4)}')
            context['ti'].xcom_push(key='inputs', value=self.__inputs)
            return 'prepare_data.check_daterange'

        except Exception as e:
            logger.error(f'Error during collecting inputs for task: {e}')
            return 'bad_task_received'
