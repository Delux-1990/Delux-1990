import json
import logging
from typing import Any
from dq_plugin.APIs.dq_service_api import DQServiceAPI
from airflow.models.baseoperator import BaseOperator


logger = logging.getLogger(__name__)


class BadTaskReceivedOperator(BaseOperator):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def execute(self, context: Any):
        logger.info('Sending to API status "failed" for received task')
        task_id = context['ti'].xcom_pull(key='task_to_process')['id']
        api = DQServiceAPI()
        api.set_task_to_failed_status(task_id)
