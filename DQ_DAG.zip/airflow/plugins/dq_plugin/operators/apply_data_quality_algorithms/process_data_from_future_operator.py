import logging
import json
from typing import Any
from airflow.models import BaseOperator
from dq_plugin.utils.database_operations import get_input_values_from_db, update_input_values_in_db
from dq_plugin.algorithms.checkers.data_from_future_checker import find_data_from_future
from dq_plugin.algorithms.fixers.data_from_future_fixer import fix_data_from_future
from dq_plugin.utils.gate_time_operations import convert_interval_to_timedelta
from dq_plugin.models import OperatorColors
from dq_plugin.models import ActionStatuses


logger = logging.getLogger(__name__)


class ProcessDataFromFutureOperator(BaseOperator):
    def __init__(self, connection_id: str, table_name: str, **kwargs):
        super().__init__(**kwargs)
        self.__connection_id = connection_id
        self.__table_name = table_name
        self.ui_color = OperatorColors.PROBLEMS_PROCESSING_OPERATOR.value

    def execute(self, context: Any):
        task_to_process = context['ti'].xcom_pull(key='task_to_process')
        to_cleanse = task_to_process['to_cleanse']
        actions_configuration = task_to_process['actions_configuration']
        task_id = context['ti'].task_id.split('.')[-1]

        if task_id in set(actions_configuration):
            inputs: dict = context['ti'].xcom_pull(key='inputs')
            task_report = dict()
            inputs_guids = list(inputs.keys())

            for input_guid in inputs_guids:
                logger.info(f'Processing input with guid {input_guid}')
                try:
                    if inputs[input_guid]['validity']['is_valid']:
                        logger.info('Checking input values')
                        df = get_input_values_from_db(self.__connection_id, self.__table_name, input_guid)
                        timedelta = convert_interval_to_timedelta(inputs[input_guid]['properties']['gate_time_interval'])
                        report = find_data_from_future(df, timedelta, inputs[input_guid]['properties']['is_forecast'])

                        if to_cleanse:
                            logger.info('Fixing input values')
                            fixed_df = fix_data_from_future(df, report)
                            update_input_values_in_db(self.__connection_id, self.__table_name, fixed_df, input_guid)

                        task_report[input_guid] = {
                            'status': report.get_status(),
                            # 'percentage': round(report.get_future_points_count() / len(df), 2),
                            'report': report.to_dict()
                        }
                    else:
                        logger.info(f'Input is invalid')
                        task_report[input_guid] = {
                            'status': ActionStatuses.INPUT_IS_INVALID.value
                        }

                except Exception as e:
                    logger.error(f'Error during processing data from future: {e}')
                    task_report[input_guid] = {
                        'status': ActionStatuses.PROCESSING_FAILED.value
                    }

            logger.info(f'Saving task report to XCOM:\n\
                        {json.dumps(task_report, indent=4)}')
            context['ti'].xcom_push(key=f'{task_id}_report', value=task_report)

        else:
            logger.info('Data from future detection is skipped for the task')
