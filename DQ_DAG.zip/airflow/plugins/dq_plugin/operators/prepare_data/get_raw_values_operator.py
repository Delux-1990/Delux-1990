import json
import logging
import pandas as pd
from typing import Any
from airflow.models.baseoperator import BaseOperator
from dq_plugin.utils.database_operations import save_input_values_to_db
from dq_plugin.APIs.value_service_api import ValueServiceAPI
from dq_plugin.models import ValidityStatuses


logger = logging.getLogger(__name__)


class GetRawValuesOperator(BaseOperator):
    def __init__(self, connection_id: str, table_name: str, **kwargs):
        super().__init__(**kwargs)
        self.__connection_id = connection_id
        self.__table_name = table_name

    def execute(self, context: Any):
        inputs: dict = context['ti'].xcom_pull(key='inputs')
        api = ValueServiceAPI()
        inputs_guids = list(inputs.keys())

        for input_guid in inputs_guids:
            if inputs[input_guid]['validity']['is_valid']:
                logger.info(f'Getting raw values for input with guid {input_guid}')
                try:
                    df = api.get_raw_input_values_data_frame(
                        input_guid=input_guid,
                        timestamp_from=pd.to_datetime(inputs[input_guid]['daterange']['timestamp_from'], utc=True),
                        timestamp_to=pd.to_datetime(inputs[input_guid]['daterange']['timestamp_to'], utc=True),
                        column_name='input_value'
                    )

                    logger.info('Saving received values for input to local database')
                    try:
                        save_input_values_to_db(self.__connection_id, self.__table_name, df, input_guid)
                        logger.info(f'Values of input with guid {input_guid} successfully saved to local database')
                    except Exception as e:
                        logger.error(f'Input is invalid due to error during saving values to local database: {e}')
                        inputs[input_guid]['validity']['is_valid'] = False
                        inputs[input_guid]['validity']['status'] = ValidityStatuses.INTERNAL_ERROR.value

                except Exception as e:
                    logger.error(f'Input is invalid due to error during getting raw values for input: {e}')
                    inputs[input_guid]['validity']['is_valid'] = False
                    inputs[input_guid]['validity']['status'] = ValidityStatuses.IS_UNREACHABLE.value

        logger.info(f'Saving inputs with updated status to XCOM:\n{json.dumps(inputs, ensure_ascii=False, indent=4)}')
        context['ti'].xcom_push(key='inputs', value=inputs)
