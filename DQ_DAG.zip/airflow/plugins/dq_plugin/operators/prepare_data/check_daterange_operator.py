import json
import logging
import pandas as pd
from airflow.models.baseoperator import BaseOperator
from typing import Any
from dq_plugin.APIs.value_service_api import ValueServiceAPI
from dq_plugin.models import ValidityStatuses


logger = logging.getLogger(__name__)


class CheckDaterangeOperator(BaseOperator):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def execute(self, context: Any):
        inputs: dict = context['ti'].xcom_pull(key='inputs')
        daterange_configuration = context['ti'].xcom_pull(key='task_to_process')['daterange_configuration']
        task_timestamp_from = daterange_configuration['timestamp_from']
        task_timestamp_to = daterange_configuration['timestamp_to']

        logger.info('Comparing inputs dateranges from API with dateranges specified in received task')
        api = ValueServiceAPI()
        inputs_guids = list(inputs.keys())
        for input_guid in inputs_guids:
            logger.info(f'Analyzing input with guid {input_guid}')
            inputs[input_guid]['validity'] = {
                'is_valid': False,
                'status': ValidityStatuses.UNDEFINED.value,
            }
            inputs[input_guid]['daterange'] = {
                'timestamp_from': task_timestamp_from,
                'timestamp_to': task_timestamp_to
            }

            try:
                input_first_timestamp, input_last_timestamp = api.get_boundary_timestamps(input_guid)

                logger.info(f'Daterange specified in task: from [{task_timestamp_from}] to [{task_timestamp_to}]')
                logger.info(f'Daterange of input from api: from [{input_first_timestamp}] to [{input_last_timestamp}]')

                if pd.to_datetime(task_timestamp_from, utc=True) < pd.to_datetime(input_last_timestamp, utc=True) and \
                        pd.to_datetime(task_timestamp_to, utc=True) > pd.to_datetime(input_first_timestamp, utc=True):

                    logger.info(f'Input is valid')
                    inputs[input_guid]['validity']['is_valid'] = True
                    inputs[input_guid]['validity']['status'] = ValidityStatuses.OK.value

                    if pd.to_datetime(task_timestamp_from, utc=True) < pd.to_datetime(input_first_timestamp, utc=True):
                        inputs[input_guid]['daterange']['timestamp_from'] = input_first_timestamp
                        inputs[input_guid]['validity']['status'] = ValidityStatuses.DATERANGE_SHORTENED.value
                    if pd.to_datetime(task_timestamp_to, utc=True) > pd.to_datetime(input_last_timestamp, utc=True):
                        inputs[input_guid]['daterange']['timestamp_to'] = input_last_timestamp
                        inputs[input_guid]['validity']['status'] = ValidityStatuses.DATERANGE_SHORTENED.value

                else:
                    logger.info(f'Input is invalid due to wrong daterange specified in task')
                    inputs[input_guid]['validity']['status'] = 'Wrong daterange specified'

            except Exception as e:
                logger.error(f'Input is invalid due to error during analyzing input daterange: {e}')
                inputs[input_guid]['validity']['status'] = ValidityStatuses.IS_UNREACHABLE.value

        logger.info(f'Saving inputs with updated status to XCOM:\n{json.dumps(inputs, ensure_ascii=False, indent=4)}')
        context['ti'].xcom_push(key='inputs', value=inputs)
