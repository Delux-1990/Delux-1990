import requests as rq
import json


class ReportingAPI:
    """Class provides interface for Reporting API interaction"""
    def __init__(self):
        # self.__url = 'https://reporting.api.oceli.energy/cugreports'
        self.__url = 'https://reporting.api.demo.oceli.energy/cugreports'
        self.__default_headers = {
            'accept': 'application/json',
            'Content-Type': 'application/json',
        }

    def create_report(self, report: dict) -> str:
        """Method send request for creating report to api and returns status code of request and created report guid"""
        rq_url = f'{self.__url}/reports'
        body = {
            'ReportType': 3,
            'CustomParameters': {
                'data': report
            }
        }
        response = rq.post(rq_url, headers=self.__default_headers, json=body)
        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f'{response.json()}')


def main():
    file = open(r'C:\Users\therm\Downloads\crazy_report.json')    # report.json
    report = json.load(file)
    api = ReportingAPI()
    report_guid = api.create_report(report)
    print(report_guid)


if __name__ == '__main__':
    main()
