import json
from ecoscada.api import Api


class EcoscadaAPI(Api):
    """Class provides interface for Ecoscada Microservice API interaction"""
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def get_all_inputs_guids_in_measurement(self, measurement_guid: str) -> list:
        """Method returns list of inputs guids in specified measurement"""
        inputs_list = self.get_measurement(measurement_guid)['inputs']

        inputs_guids = []
        for single_input in inputs_list:
            inputs_guids.append(single_input['guid'])

        return inputs_guids

    def get_all_measurements_guids_in_building(self, building_guid: str) -> list:
        """Method returns list of measurements guids in specified building"""
        measurements_list = self.get_building_measurements(building_guid)

        measurements_guids = []
        for single_measurement in measurements_list:
            measurements_guids.append(single_measurement['guid'])

        return measurements_guids

    def get_all_buildings_guids_in_cug(self, cug_guid: str) -> list:
        """Method returns list of buildings guids in specified cug"""
        buildings_list = self.get_cug_buildings(cug_guid)

        buildings_guids = []
        for single_building in buildings_list:
            buildings_guids.append(single_building['guid'])

        return buildings_guids


def main():
    api = EcoscadaAPI()

    cug_guid = 'f07f1fd9-86b7-404c-a0b0-f4f5f964c482'
    building_guid = '871b5be2-cb80-40da-994a-c381feeda258'
    measurement_guid = '0260db13-8c3b-4ced-a571-397f7c224410'
    input_guid = '4bd61fba-066a-4e7f-87e9-69505505ca36'

    print(json.dumps(api.get_input(input_guid), indent=4))


if __name__ == '__main__':
    main()
