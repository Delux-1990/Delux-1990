import json
import requests as rq
from enum import Enum
from typing import Union, Dict, List


class RequestStatuses(Enum):
    QUEUED = 1
    IN_PROCESS = 2
    SUCCESSED_FINISHED = 3
    FAILED = 4
    SENT = 5
    SENDING_FAILED = 6


class DQServiceAPI:
    """Class provides interface for DQ Microservice API interaction"""
    def __init__(self):
        self.__url = 'http://demo.api.dq.oceli.energy'
        self.__default_headers = {
            'accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer CWEXFYH2J3K4N6P7Q9SBTBVDWEXGZH2J4M5N6Q8R9SBUCVDXFYGZH3K4M5',
            'X-EcoSCADA-UserGuid': '582B1EA0-B43B-4CB3-9770-46C18DE01AB4',
            'X-DQ-Api-Key': '777'
        }
    
    def __get_tasks_by_status(self, status: RequestStatuses) -> List[Dict]:
        """Method returns list of dictionaries with info about tasks by specified status"""
        rq_url = f'{self.__url}/v1/requests?statusId={status.value}'
        response = rq.get(rq_url, headers=self.__default_headers)
        return response.json()

    def get_tasks_from_queue(self) -> List[Dict]:
        """Method returns tasks from queue"""
        return self.__get_tasks_by_status(status=RequestStatuses.QUEUED)

    def __set_task_to_specific_status(self, task_id: int, status: RequestStatuses):
        """Method sets specified status for tasks by id"""
        rq_url = f'{self.__url}/v1/requests/{task_id}'
        json_data = [{
            'op': 'replace',
            'value': str(status.value),
            'path': '/requestStatusId'
        }]
        patch_headers = self.__default_headers
        patch_headers['Content-Type'] = 'application/json-patch+json'
        return rq.patch(rq_url, json=json_data, headers=patch_headers)

    def set_task_to_in_process_status(self, task_id: int):
        """Method sets 'in_process' status for tasks by id"""
        return self.__set_task_to_specific_status(task_id, RequestStatuses.IN_PROCESS)

    def set_task_to_failed_status(self, task_id: int):
        """Method sets 'failed' status for tasks by id"""
        return self.__set_task_to_specific_status(task_id, RequestStatuses.FAILED)

    def set_task_to_successed_finished_status(self, task_id: int):
        """Method sets 'successed finished' status for tasks by id"""
        return self.__set_task_to_specific_status(task_id, RequestStatuses.SUCCESSED_FINISHED)

    def set_task_to_sent_status(self, task_id: int):
        """Method sets 'sent' status for tasks by id"""
        return self.__set_task_to_specific_status(task_id, RequestStatuses.SENT)

    def set_task_to_sending_failed_status(self, task_id: int):
        """Method sets 'sending_failed' status for tasks by id"""
        return self.__set_task_to_specific_status(task_id, RequestStatuses.SENDING_FAILED)

    def attach_report_for_task(self, task_id: int, report_guid: str):
        """Method adds report guid to processed task by id"""
        rq_url = f'{self.__url}/v1/requests/{task_id}'
        json_data = [{
            'op': 'replace',
            'value': report_guid,
            'path': '/reportGuid'
        }]
        patch_headers = self.__default_headers
        patch_headers['Content-Type'] = 'application/json-patch+json'
        return rq.patch(rq_url, json=json_data, headers=patch_headers)

    def attach_details_for_task(self, task_id: int, details: str):
        """Method adds details to processed task by id"""
        rq_url = f'{self.__url}/v1/requests/{task_id}'
        json_data = [{
            'op': 'replace',
            'value': details,
            'path': '/details'
        }]
        patch_headers = self.__default_headers
        patch_headers['Content-Type'] = 'application/json-patch+json'
        return rq.patch(rq_url, json=json_data, headers=patch_headers)

    def create_fixed_input(self, input_guid, measurement_guid, building_guid):
        """Method creates in ecoscada new input for fixed data and returns created input guid"""
        rq_url = f'{self.__url}/v1/inputs/create-fixed'
        json_data = {
            'inputGuid': input_guid,
            'measurementGuid': measurement_guid,
            'buildingGuid': building_guid
        }
        response = rq.post(rq_url, json=json_data, headers=self.__default_headers)
        return response.json()['fixedInputGuid']


def main():
    api = DQServiceAPI()

    cug_guid = 'f07f1fd9-86b7-404c-a0b0-f4f5f964c482'
    building_guid = '871b5be2-cb80-40da-994a-c381feeda258'
    measurement_guid = '0260db13-8c3b-4ced-a571-397f7c224410'
    input_guid = '4bd61fba-066a-4e7f-87e9-69505505ca36'

    print(json.dumps(api.create_fixed_input(input_guid, measurement_guid, building_guid), indent=4))


if __name__ == '__main__':
    main()
