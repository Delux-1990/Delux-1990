import requests as rq
import pandas as pd
import json
from typing import Optional, List
from dq_plugin.models import INPUT_TYPES


class ValueServiceAPI:
    """Class provides interface for Value Microservice API interaction"""
    def __init__(self):
        self.__url = 'http://value.prod.ileco.internal'
        self.__default_headers = {
            'accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer CWEXFYH2J3K4N6P7Q9SBTBVDWEXGZH2J4M5N6Q8R9SBUCVDXFYGZH3K4M5',
            'X-EcoSCADA-UserGuid': '582B1EA0-B43B-4CB3-9770-46C18DE01AB4',
            'X-DQ-Api-Key': '777'
        }
        self.__input_types = {
            1: 'pulses',
            5: 'meter-readings'
        }

    @staticmethod
    def parse_timestamp(timestamp: pd.Timestamp) -> str:
        """Method returns parsed timestamp with utc timezone as a string in format <yyyy-mm-ddThh:mm:ssZ>"""
        return str(pd.to_datetime(timestamp, utc=True)).split('+')[0].replace(' ', 'T') + 'Z'

    def get_boundary_timestamps(self, input_guid: str) -> tuple:
        """Method returns first and last timestamps as a tuple of input by specified guid"""
        rq_url = f'{self.__url}/v1/input/{input_guid}/stats'
        response = rq.get(rq_url, headers=self.__default_headers)
        return response.json()['firstTimestamp'], response.json()['lastTimestamp']

    def get_raw_input_values_data_frame(self, input_guid: str,
                                        timestamp_from: pd.Timestamp,
                                        timestamp_to: pd.Timestamp,
                                        column_name: str) -> pd.DataFrame:
        """Method returns dataframe with input values in specified date range"""
        parsed_timestamp_from = self.parse_timestamp(timestamp_from)
        parsed_timestamp_to = self.parse_timestamp(timestamp_to)

        rq_url = f'{self.__url}/v1/input/{input_guid}/raw?from={parsed_timestamp_from}&to={parsed_timestamp_to}'
        response = rq.get(rq_url, headers=self.__default_headers)

        timestamps = []
        values = []
        for item in response.json():
            timestamps.append(pd.to_datetime(item['ts'], utc=True))
            values.append(item['v'])
        return pd.DataFrame({column_name: values}, index=timestamps)

    def put_input_values(self, input_guid: str, df: pd.DataFrame, input_type_id: int) -> rq.Response:
        rq_url = f'{self.__url}/v1/raw_value/input/{input_guid}/{self.__input_types[input_type_id]}'
        json_data = [
            {
                'value': row_items[0],
                'timestamp': str(index)
            } for index, row_items in df.iterrows()
        ]

        headers = self.__default_headers
        headers['Content-Type'] = 'application/json-patch+json'
        return rq.put(rq_url, json=json_data, headers=headers)

    def get_inputs_by_formula(self, measurement_guid: str) -> Optional[List]:
        rq_url = f'{self.__url}/v1/measurement/{measurement_guid}/dependencies/inputs'
        dependent_inputs = rq.get(rq_url, headers=self.__default_headers).json()
        if not dependent_inputs:
            return []
        else:
            return [item['guid'] for item in dependent_inputs]


def main():
    input_guid = '12cd12f7-4665-49b2-b1e7-70bc730364e3'
    measurement_with_formula_guid = '635a0866-25af-48d4-b771-ea150e4000f7'
    timestamp_from = pd.Timestamp(2021, 1, 1)
    timestamp_to = pd.Timestamp(2021, 1, 2)

    api = ValueServiceAPI()
    df = pd.DataFrame({'ts': ['2020-05-30T15:00:00'], 'input_value': [4.152]})
    df.set_index('ts', drop=True, inplace=True)
    print(api.put_input_values(input_guid, df, 1))


if __name__ == '__main__':
    main()
