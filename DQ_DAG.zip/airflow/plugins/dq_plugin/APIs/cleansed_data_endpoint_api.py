import json
import requests as rq


class CleansedDataEndpointApi:
    """Class provides interface for endpoint interaction where cleansed data will be sent"""
    def __init__(self, url):
        self.__url = url
        self.__default_headers = {
            'accept': 'application/json',
            'Content-Type': 'application/json',
        }

    def send_cleansed_data_info(self, original_input_guid, fixed_input_guid) -> rq.Response:
        """Method sends a pair of original and fixed input guids to endpoint"""
        rq_url = f'{self.__url}'
        json_data = {
            'originalInputGuid': original_input_guid,
            'fixedInputGuid': fixed_input_guid
        }
        return rq.post(rq_url, json=json_data, headers=self.__default_headers)


def main():
    api = CleansedDataEndpointApi('https://example.com')
    print(api.send_cleansed_data_info('pupa', 'fixed_pupa'))


if __name__ == '__main__':
    main()
