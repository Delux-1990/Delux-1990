import pandas as pd
import numpy
import dq_plugin.algorithms.reports.dq_components as dqc
from dq_plugin.models import INPUT_TYPES
from dq_plugin.models import ActionStatuses


class CheckerReport:
    def __init__(self, start_timestamp: pd.Timestamp, end_timestamp: pd.Timestamp, timedelta: pd.Timedelta):
        self.__start_timestamp = start_timestamp
        self.__end_timestamp = end_timestamp
        self.__timedelta = timedelta
        self.__problems_count = 0
        self.__problems = []

    def _add_problem(self, problem: dqc.ProblematicPoint) -> None:
        self.__problems.append(problem)
        self.__problems_count += 1

    def _get_problems_count(self) -> int:
        return self.__problems_count

    def _get_problems(self) -> list:
        return self.__problems

    def get_start_timestamp(self):
        return self.__start_timestamp

    def get_end_timestamp(self):
        return self.__end_timestamp

    def get_timedelta(self):
        return self.__timedelta

    def get_status(self):
        if self._get_problems_count() > 0:
            return ActionStatuses.ISSUES_FOUND.value
        else:
            return ActionStatuses.ISSUES_NOT_FOUND.value


class GapsCheckerReport(CheckerReport):
    def __init__(self, start_timestamp: pd.Timestamp, end_timestamp: pd.Timestamp, timedelta: pd.Timedelta):
        super().__init__(start_timestamp, end_timestamp, timedelta)
        self.__shifted_gaps_count = 0
        self.__lost_gaps_count = 0

    def add_gap_as_shifted(self, timestamp: pd.Timestamp, fit_timestamp: pd.Timestamp) -> None:
        self._add_problem(dqc.Gap(timestamp, dqc.GapTypes.SHIFTED, fit_timestamp))
        self.__shifted_gaps_count += 1

    def add_gap_as_lost(self, timestamp: pd.Timestamp) -> None:
        self._add_problem(dqc.Gap(timestamp, dqc.GapTypes.LOST))
        self.__lost_gaps_count += 1

    def get_gaps_count(self) -> int:
        return self._get_problems_count()

    def get_shifted_gaps_count(self) -> int:
        return self.__shifted_gaps_count

    def get_lost_gaps_count(self) -> int:
        return self.__lost_gaps_count

    def get_gaps(self) -> list:
        return self._get_problems()

    def get_gaps_timestamps(self) -> list:
        timestamps = [gap.get_timestamp() for gap in self.get_gaps()]
        return timestamps

    def to_dict(self) -> dict:
        gaps = [
            {
                'timestamp': str(gap.get_timestamp()),
                'type': gap.get_str_type(),
                'fit': str(gap.get_fit_timestamp())
            } for gap in self.get_gaps()
        ]

        return {
            'aligned_daterange': {
                'timestamp_from': str(self.get_start_timestamp()),
                'timestamp_to': str(self.get_end_timestamp()),
            },
            'gaps_count': {
                'total': self.get_gaps_count(),
                'shifted': self.get_shifted_gaps_count(),
                'lost': self.get_lost_gaps_count(),
            },
            'gaps': gaps
        }


class OutliersCheckerReport(CheckerReport):
    def __init__(self, start_timestamp: pd.Timestamp, end_timestamp: pd.Timestamp, timedelta: pd.Timedelta):
        super().__init__(start_timestamp, end_timestamp, timedelta)

    def add_outlier(self, timestamp: pd.Timestamp, value: numpy.float64,
                    previous_value: numpy.float64, next_value: numpy.float64) -> None:
        self._add_problem(dqc.Outlier(timestamp, value, previous_value, next_value))

    def get_outliers_count(self) -> int:
        return self._get_problems_count()

    def get_outliers(self) -> list:
        return self._get_problems()

    def get_outliers_timestamps(self) -> list:
        timestamps = [outlier.get_timestamp() for outlier in self.get_outliers()]
        return timestamps

    def get_outliers_values(self) -> list:
        values = [outlier.get_value() for outlier in self.get_outliers()]
        return values

    def to_dict(self) -> dict:
        outliers = [
            {
                'timestamp': str(outlier.get_timestamp()),
                'value': outlier.get_value()
            } for outlier in self.get_outliers()
        ]

        return {
            'outliers_count': self.get_outliers_count(),
            'outliers': outliers
        }


class AnomalyCheckerReport(CheckerReport):
    def __init__(self, start_timestamp: pd.Timestamp, end_timestamp: pd.Timestamp, timedelta: pd.Timedelta):
        super().__init__(start_timestamp, end_timestamp, timedelta)

    def add_anomaly(self, timestamp: pd.Timestamp, value: numpy.float64) -> None:
        self._add_problem(dqc.Anomaly(timestamp, value))

    def get_anomalies_count(self) -> int:
        return self._get_problems_count()

    def get_anomalies(self) -> list:
        return self._get_problems()

    def get_anomalies_timestamps(self) -> list:
        timestamps = [anomaly.get_timestamp() for anomaly in self.get_anomalies()]
        return timestamps

    def get_anomalies_values(self) -> list:
        values = [anomaly.get_value() for anomaly in self.get_anomalies()]
        return values

    def to_dict(self) -> dict:
        anomalies = [
            {
                'timestamp': str(anomaly.get_timestamp()),
                'value': anomaly.get_value()
            } for anomaly in self.get_anomalies()
        ]

        return {
            'anomalies_count': self.get_anomalies_count(),
            'anomalies': anomalies
        }


class DataFromFutureCheckerReport(CheckerReport):
    def __init__(self, start_timestamp: pd.Timestamp, end_timestamp: pd.Timestamp,
                 timedelta: pd.Timedelta, is_forecast: bool):
        super().__init__(start_timestamp, end_timestamp, timedelta)
        self.__start_timestamp = start_timestamp
        self.__end_timestamp = end_timestamp
        self.__timedelta = timedelta
        self.__is_forecast = is_forecast

    def add_future_point(self, timestamp: pd.Timestamp, value: numpy.float64) -> None:
        self._add_problem(dqc.FuturePoint(timestamp, value))

    def get_future_points_count(self) -> int:
        return self._get_problems_count()

    def get_future_points(self) -> list:
        return self._get_problems()

    def get_future_points_timestamps(self) -> list:
        timestamps = [future_point.get_timestamp() for future_point in self.get_future_points()]
        return timestamps

    def get_future_points_values(self) -> list:
        values = [future_point.get_value() for future_point in self.get_future_points()]
        return values

    def is_forecast(self):
        return self.__is_forecast

    def to_dict(self) -> dict:
        future_points = [
            {
                'timestamp': str(future_point.get_timestamp()),
                'value': future_point.get_value()
            } for future_point in self.get_future_points()
        ]

        return {
            'future_points_count': self.get_future_points_count(),
            'is_forecast': self.is_forecast(),
            'future_points': future_points
        }


class InputTypeClassifierReport:
    def __init__(self, is_meterreading: bool, is_pulse: bool, input_type_id: int, is_meter_bidirectional: bool):
        self.__is_meterreading = is_meterreading
        self.__is_pulse = is_pulse
        self.__input_type_id = input_type_id
        self.__is_meter_bidirectional = is_meter_bidirectional
        self.__input_types = INPUT_TYPES

    def get_status(self):
        if [self.__is_meterreading, self.__is_pulse].count(True) == 1:
            return ActionStatuses.TYPE_IS_DEFINED.value
        else:
            return ActionStatuses.TYPE_IS_NOT_DEFINED.value

    def to_dict(self):
        return {
            'ecoscada_info': {
                'ecoscada_input_type': self.__input_types[self.__input_type_id],
                'is_meter_bidirectional': self.__is_meter_bidirectional
            },
            'type_classification': {
                'is_meterreading': self.__is_meterreading,
                'is_pulse': self.__is_pulse
            }
        }


class InputProfileClassifierReport:
    def __init__(self, is_solar: bool, is_grid: bool):
        self.__is_solar = is_solar
        self.__is_grid = is_grid

    def get_status(self):

        if [self.__is_solar, self.__is_grid].count(True) == 1:
            return ActionStatuses.PROFILE_IS_DEFINED.value
        else:
            return ActionStatuses.PROFILE_IS_NOT_DEFINED.value

    def to_dict(self):
        return {
            'profile_classification': {
                'is_solar': self.__is_solar,
                'is_grid': self.__is_grid
            }
        }
