import numpy
import pandas as pd
from enum import Enum


class ProblematicPoint:
    def __init__(self, timestamp: pd.Timestamp):
        self.__timestamp = timestamp

    def get_timestamp(self) -> pd.Timestamp:
        return self.__timestamp


class GapTypes(Enum):
    SHIFTED = 'shifted'
    LOST = 'lost'


class Gap(ProblematicPoint):
    def __init__(self, timestamp: pd.Timestamp, gap_type: GapTypes, fit_timestamp: pd.Timestamp = None):
        super().__init__(timestamp)
        self.__gap_type = gap_type
        self.__fit_timestamp = fit_timestamp

        if gap_type == GapTypes.LOST:
            self.__fit_timestamp = None

    def get_fit_timestamp(self) -> pd.Timestamp:
        return self.__fit_timestamp

    def get_str_type(self) -> str:
        return self.__gap_type.value

    def is_shifted(self) -> bool:
        return self.__gap_type == GapTypes.SHIFTED

    def is_lost(self) -> bool:
        return self.__gap_type == GapTypes.LOST


class Outlier(ProblematicPoint):
    def __init__(self, timestamp: pd.Timestamp, value: numpy.float_,
                 previous_value: numpy.float_, next_value: numpy.float_):
        super().__init__(timestamp)
        self.__value = value
        self.__previous_value = previous_value
        self.__next_value = next_value

    def get_value(self) -> numpy.float_:
        return self.__value

    def get_previous_value(self) -> numpy.float_:
        return self.__previous_value

    def get_next_value(self) -> numpy.float_:
        return self.__next_value


class Anomaly(ProblematicPoint):
    def __init__(self, timestamp: pd.Timestamp, value: numpy.float_):
        super().__init__(timestamp)
        self.__value = value

    def get_value(self) -> numpy.float_:
        return self.__value


class FuturePoint(ProblematicPoint):
    def __init__(self, timestamp: pd.Timestamp, value: numpy.float_):
        super().__init__(timestamp)
        self.__value = value

    def get_value(self) -> numpy.float_:
        return self.__value
