import pandas as pd


def check_for_grid(df: pd.DataFrame):
    return False
