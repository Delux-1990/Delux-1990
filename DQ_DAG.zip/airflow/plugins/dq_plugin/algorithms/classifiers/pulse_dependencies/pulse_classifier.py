import pandas as pd


def check_for_pulse(df: pd.DataFrame):
    return False
