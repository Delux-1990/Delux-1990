import pandas as pd
from dq_plugin.algorithms.classifiers.solar_dependencies.solar_classifier import check_for_solar
from dq_plugin.algorithms.reports.reports import InputProfileClassifierReport
from dq_plugin.algorithms.classifiers.grid_dependencies.grid_classifier import check_for_grid


def classify_input_profile(df: pd.DataFrame, timedelta: pd.Timedelta) -> InputProfileClassifierReport:
    is_solar = check_for_solar(df, timedelta)
    return InputProfileClassifierReport(is_solar=is_solar,
                                        is_grid=not is_solar)
