import pandas as pd


def check_for_meterreading(df: pd.DataFrame, is_bidirectional: bool) -> bool:
    ADMISSION_THRESHOLD = 0.05

    if is_bidirectional:
        direction_changes_count = 0
        direction_is_increasing = df['input_value'][0] <= df['input_value'][1]
        for i in range(2, len(df)):
            if direction_is_increasing:
                if df['input_value'][i - 1] > df['input_value'][i]:
                    direction_is_increasing = not direction_is_increasing
                    direction_changes_count += 1
            else:
                if df['input_value'][i - 1] < df['input_value'][i]:
                    direction_is_increasing = not direction_is_increasing
                    direction_changes_count += 1

        print(direction_changes_count, direction_changes_count / len(df))
        if direction_changes_count / len(df) > ADMISSION_THRESHOLD:
            return False

    else:
        declines_count = 0
        for i in range(1, len(df)):
            if df['input_value'][i - 1] > df['input_value'][i]:
                declines_count += 1

        if (declines_count / len(df)) > ADMISSION_THRESHOLD:
            return False

    return True


def main():
    from dq_plugin.APIs.value_service_api import ValueServiceAPI
    from dq_plugin.utils.dataframe_operations import normalize_dataframe
    import dq_plugin.utils.visualizer as vsl

    local_mode = True
    if local_mode:
        df = normalize_dataframe(pd.read_csv('../../../../../../local/csv/custom_bidirectional.csv',
                                             delimiter=',', decimal='.', index_col='ds'))
    else:
        api = ValueServiceAPI()
        input_guid = '21667970-75ac-4240-919f-b3938b6091b9'
        df = normalize_dataframe(api.get_raw_input_values_data_frame(input_guid,
                                                                     pd.Timestamp('2019-12-31'),
                                                                     pd.Timestamp('2021-02-11'),
                                                                     'input_value'))

    print(check_for_meterreading(df, True))
    vsl.show(df.index, df['input_value'])


if __name__ == '__main__':
    main()
