import os
import logging
import numpy as np
import pandas as pd

from ecoscada import Input
from ecoscada.models import GateTime


SOLAR_DAY_COUNT = 28

logger = logging.getLogger(__name__)


def scaled_mean_absolute_error(y_true: pd.DataFrame, y_pred: pd.DataFrame):
    # logger.info(y_true)
    result = (y_true - y_pred).abs().sum() * np.mean(y_true.abs()) / len(y_true)
    if np.isnan(result['input_value']):
        # logger.info('---')
        # logger.info(y_true.to_string())
        # logger.info('---')
        # logger.info(y_pred.to_string())
        # logger.info('---')
        return 100
    return result['input_value']


def check_for_solar(df: pd.DataFrame, timedelta: pd.Timedelta):
    # Determination of gate time frequency
    FREQ = int(pd.Timedelta(1, unit='d') / timedelta)

    # Preparing dataframes
    test_set = pd.read_csv(f'{os.path.dirname(__file__)}/solar_sample.csv', index_col=0)
    test_set = test_set / test_set.max()
    test_set = test_set.replace(np.inf, 0).fillna(0)

    df_period = df[:SOLAR_DAY_COUNT * FREQ]
    df_period.index = [
        index.strftime('%m-%d %H:%M:%S')
        for index in df_period.index
    ]
    df_period = df_period / df_period.max()

    intersected_rows = test_set.loc[test_set.index.intersection(df_period.index)]
    df_test = pd.DataFrame({'input_value': intersected_rows.iloc[:, 0]})

    solar_error = scaled_mean_absolute_error(df_test, df_period)
    for i in range(1, len(test_set.columns)):
        df_test = pd.DataFrame({'input_value': intersected_rows.iloc[:, i]})
        error = scaled_mean_absolute_error(df_test, df_period)
        if error < solar_error:
            solar_error = error

    return True if solar_error < 5 else False
