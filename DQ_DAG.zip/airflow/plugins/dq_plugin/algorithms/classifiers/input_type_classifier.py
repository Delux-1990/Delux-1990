import pandas as pd
from dq_plugin.algorithms.reports.reports import InputTypeClassifierReport
from dq_plugin.algorithms.classifiers.meterreading_dependencies.meterreading_classifier import check_for_meterreading
from dq_plugin.algorithms.classifiers.pulse_dependencies.pulse_classifier import check_for_pulse


def classify_input_type(df: pd.DataFrame, input_type_id: int, is_bidirectional: bool) -> InputTypeClassifierReport:
    is_meterreading = check_for_meterreading(df, is_bidirectional=is_bidirectional)
    return InputTypeClassifierReport(is_meterreading=is_meterreading,
                                     is_pulse=not is_meterreading,
                                     input_type_id=input_type_id,
                                     is_meter_bidirectional=is_bidirectional)
