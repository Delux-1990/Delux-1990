import pandas as pd
from dq_plugin.algorithms.reports.reports import DataFromFutureCheckerReport


FORECAST_DAYS_COUNT = 14


def find_data_from_future(df: pd.DataFrame, timedelta: pd.Timedelta, is_forecast: bool) -> DataFromFutureCheckerReport:
    if is_forecast:
        boundary_timestamp = pd.Timestamp.now(tz='utc') + pd.Timedelta(FORECAST_DAYS_COUNT, unit='d')
    else:
        boundary_timestamp = pd.Timestamp.now(tz='utc')

    data_from_future = df[df.index > boundary_timestamp]

    report = DataFromFutureCheckerReport(df.index[0], df.index[-1], timedelta, is_forecast)
    for index, row in data_from_future.iterrows():
        report.add_future_point(index, row[0])

    return report


def main():
    import json
    from dq_plugin.APIs.value_service_api import ValueServiceAPI
    from dq_plugin.utils.dataframe_operations import normalize_dataframe

    local_mode = False
    if local_mode:
        df = normalize_dataframe(pd.read_csv('../../../../../local/csv/smart_meter_gas_consumption.csv',
                                             delimiter=',', index_col='ds'))
        df_timedelta = pd.to_timedelta('00:05:00')
    else:
        api = ValueServiceAPI()
        input_guid = '12cd12f7-4665-49b2-b1e7-70bc730364e3'
        df = normalize_dataframe(api.get_raw_input_values_data_frame(input_guid,
                                                                     pd.Timestamp(2021, 1, 1),
                                                                     pd.Timestamp(2021, 1, 30),
                                                                     'input_value'))
        df_timedelta = pd.to_timedelta('00:15:00')

    report = find_data_from_future(df, df_timedelta, is_forecast=False)
    print(report.get_status())
    print(json.dumps(report.to_dict(), indent=4))


if __name__ == '__main__':
    main()
