import pandas as pd
from dq_plugin.algorithms.reports.reports import GapsCheckerReport


def find_gaps(dataframe: pd.DataFrame, timedelta: pd.Timedelta) -> GapsCheckerReport:
    """
    Functions finds two kind of gaps:
    1. Lost gaps (if we have no value directly and nearby timestamp)
    2. Shifted gaps (if we have no value directly at timestamp, but it exists nearby)
    :param dataframe: exploring dataframe
    :param timedelta: time step between neighbour measurements in dataframe
    :return: GapsCheckerReport object with information about found gaps
    """

    def get_nearest_aligned_timestamp(timestamp: pd.DatetimeIndex):
        offset_from_left = pd.to_timedelta(timestamp.minute % (timedelta.seconds / 60), unit='minutes')
        offset_from_right = timedelta - offset_from_left

        if offset_from_left < offset_from_right:
            return (timestamp - offset_from_left).replace(second=0)
        else:
            return (timestamp + offset_from_right).replace(second=0)

    start_timestamp = get_nearest_aligned_timestamp(dataframe.index[0])
    end_timestamp = get_nearest_aligned_timestamp(dataframe.index[-1])
    exploring_timestamp = start_timestamp

    report = GapsCheckerReport(start_timestamp, end_timestamp, timedelta)

    while exploring_timestamp <= end_timestamp:
        if exploring_timestamp not in dataframe.index:
            nearest_timestamp = dataframe.index[dataframe.index.get_loc(exploring_timestamp, method='nearest')]

            if (exploring_timestamp - timedelta / 2) <= nearest_timestamp < (exploring_timestamp + timedelta / 2):
                report.add_gap_as_shifted(exploring_timestamp, nearest_timestamp)
            else:
                report.add_gap_as_lost(exploring_timestamp)
        exploring_timestamp += timedelta

    return report


def main():
    import json
    import dq_plugin.utils.visualizer as vsl
    from dq_plugin.APIs.value_service_api import ValueServiceAPI
    from dq_plugin.utils.dataframe_operations import normalize_dataframe

    local_mode = True
    if local_mode:
        df = normalize_dataframe(pd.read_csv('../../../../../local/csv/smart_meter_gas_consumption.csv',
                                             delimiter=',', index_col='ds', nrows=100))
        df_timedelta = pd.to_timedelta('00:05:00')
    else:
        api = ValueServiceAPI()
        input_guid = '12cd12f7-4665-49b2-b1e7-70bc730364e3'
        df = normalize_dataframe(api.get_raw_input_values_data_frame(input_guid,
                                                                     pd.Timestamp(2021, 1, 1),
                                                                     pd.Timestamp(2021, 1, 2),
                                                                     'input_value'))
        df_timedelta = pd.to_timedelta('00:15:00')

    report = find_gaps(df, df_timedelta)
    print(json.dumps(report.to_dict(), indent=4))
    vsl.show_with_vertical_lines(df.index, df['input_value'], report.get_gaps_timestamps(), base_mode='lines+markers')


if __name__ == '__main__':
    main()
