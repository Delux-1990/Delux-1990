import pandas as pd
from dq_plugin.algorithms.reports.reports import OutliersCheckerReport
from sklearn.cluster import DBSCAN


def find_outliers(dataframe: pd.DataFrame, timedelta: pd.Timedelta) -> OutliersCheckerReport:
    """
    Function finds outliers in a dataframe.
    :param dataframe: exploring dataframe
    :param timedelta: time step between neighbour measurements in dataframe
    :return: OutliersCheckerReport object with information about outliers
    """

    # find absolute differences between all values in dataframe
    absolute_differences = []
    for i in range(1, len(dataframe)):
        previous_value = dataframe['input_value'][i - 1]
        current_value = dataframe['input_value'][i]
        absolute_differences.append(abs(current_value - previous_value))

    # cut off most of the small differences for fast clustering
    upper_quantile = pd.Series(absolute_differences).quantile(0.9)
    differences_to_clustering = []
    for difference in absolute_differences:
        if difference > upper_quantile:
            differences_to_clustering.append([difference])

    # clustering differences
    model = DBSCAN(eps=upper_quantile, min_samples=5).fit(differences_to_clustering)
    labels = list(model.labels_)

    # find maximum difference in main cluster
    acceptable_difference = 0
    for i in range(len(labels)):
        if labels[i] == 0 and acceptable_difference < differences_to_clustering[i][0]:
            acceptable_difference = differences_to_clustering[i][0]

    def is_outlier_triad(left_value, middle_value, right_value):
        lr_difference = abs(left_value - right_value)
        lm_difference = abs(left_value - middle_value)
        rm_difference = abs(right_value - middle_value)
        return not lr_difference > acceptable_difference \
               and lm_difference > acceptable_difference \
               and rm_difference > acceptable_difference

    report = OutliersCheckerReport(dataframe.index[0], dataframe.index[-1], timedelta)

    for i in range(1, len(dataframe) - 1):
        if is_outlier_triad(dataframe['input_value'][i - 1],
                            dataframe['input_value'][i],
                            dataframe['input_value'][i + 1]):
            report.add_outlier(dataframe.index[i],
                               dataframe['input_value'][i],
                               dataframe['input_value'][i - 1],
                               dataframe['input_value'][i + 1])

    return report


def main():
    import json
    import dq_plugin.utils.visualizer as vsl
    from dq_plugin.APIs.value_service_api import ValueServiceAPI
    from dq_plugin.utils.dataframe_operations import normalize_dataframe

    local_mode = False
    if local_mode:
        df = normalize_dataframe(pd.read_csv('../../../../../local/csv/smart_meter_gas_consumption.csv',
                                             delimiter=',', index_col='ds'))
        df_timedelta = pd.to_timedelta('00:05:00')
    else:
        api = ValueServiceAPI()
        input_guid = '12cd12f7-4665-49b2-b1e7-70bc730364e3'
        df = normalize_dataframe(api.get_raw_input_values_data_frame(input_guid,
                                                                     pd.Timestamp(2021, 1, 1),
                                                                     pd.Timestamp(2021, 1, 30),
                                                                     'input_value'))
        df_timedelta = pd.to_timedelta('00:15:00')

    report = find_outliers(df, df_timedelta)
    print(json.dumps(report.to_dict(), indent=4))
    vsl.show_with_overlay(df.index, df['input_value'], report.get_outliers_timestamps(), report.get_outliers_values())


if __name__ == '__main__':
    main()
