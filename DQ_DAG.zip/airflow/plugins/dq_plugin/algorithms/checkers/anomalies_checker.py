import os
import pandas as pd
from azure.ai.anomalydetector import AnomalyDetectorClient
from azure.ai.anomalydetector.models import DetectRequest, TimeSeriesPoint, AnomalyDetectorError
from azure.core.credentials import AzureKeyCredential
from dq_plugin.algorithms.reports.reports import AnomalyCheckerReport


def find_anomalies(dataframe: pd.DataFrame, timedelta: pd.Timedelta,
                   subscription_key: str, anomaly_detector_endpoint: str) -> AnomalyCheckerReport:
    """
    Function finds anomalies in a dataframe.
    :param dataframe: exploring dataframe
    :param timedelta: time step between neighbour measurements in dataframe
    :param subscription_key: azure anomaly subscription key
    :param anomaly_detector_endpoint: azure anomaly endpoint
    :return: AnomalyCheckerReport object with information about anomalies
    """

    timedelta_parameters = {
        pd.to_timedelta('00:01:00'): ('minutely', 1),
        pd.to_timedelta('00:02:00'): ('minutely', 2),
        pd.to_timedelta('00:03:00'): ('minutely', 3),
        pd.to_timedelta('00:05:00'): ('minutely', 5),
        pd.to_timedelta('00:10:00'): ('minutely', 10),
        pd.to_timedelta('00:15:00'): ('minutely', 15),
        pd.to_timedelta('00:30:00'): ('minutely', 30),
        pd.to_timedelta('01:00:00'): ('hourly', 1),
        pd.to_timedelta('04:00:00'): ('hourly', 4),
    }

    client = AnomalyDetectorClient(AzureKeyCredential(subscription_key), anomaly_detector_endpoint)

    batch_size = 8640   # API limit for one request
    dataframe_batches = [dataframe[i: i + batch_size] for i in range(0, len(dataframe), batch_size)]
    report = AnomalyCheckerReport(dataframe.index[0], dataframe.index[-1], timedelta)

    for batch in dataframe_batches:
        series = []
        for index, row in batch.iterrows():
            series.append(TimeSeriesPoint(timestamp=pd.Timestamp(index).isoformat(), value=row['input_value']))

        request = DetectRequest(
            series=series,
            granularity=timedelta_parameters[timedelta][0],
            custom_interval=timedelta_parameters[timedelta][1],
            sensitivity=50,
        )

        response = client.detect_entire_series(request)
        if any(response.is_anomaly):
            for i, value in enumerate(response.is_anomaly):
                if value:
                    report.add_anomaly(batch.index[i], batch['input_value'][i])

    return report


def main():
    import json
    import dq_plugin.utils.visualizer as vsl
    from dq_plugin.APIs.value_service_api import ValueServiceAPI
    from dq_plugin.utils.dataframe_operations import normalize_dataframe

    local_mode = False
    if local_mode:
        df = normalize_dataframe(pd.read_csv('../../../../../local/csv/grid_p4_active_energy_balance.csv',
                                             delimiter=';', decimal=',', index_col='ds', nrows=8000))
        df_timedelta = pd.to_timedelta('00:15:00')
    else:
        api = ValueServiceAPI()
        input_guid = '12cd12f7-4665-49b2-b1e7-70bc730364e3'
        df = normalize_dataframe(api.get_raw_input_values_data_frame(input_guid,
                                                                     pd.Timestamp(2021, 1, 1),
                                                                     pd.Timestamp(2021, 1, 30),
                                                                     'input_value'))
        df_timedelta = pd.to_timedelta('00:15:00')

    report = find_anomalies(df, df_timedelta, os.getenv('ANOMALY_DETECTOR_KEY'), os.getenv('ANOMALY_DETECTOR_ENDPOINT'))
    print(json.dumps(report.to_dict(), indent=4))
    vsl.show_with_overlay(df.index, df['input_value'], report.get_anomalies_timestamps(), report.get_anomalies_values())


if __name__ == '__main__':
    main()
    