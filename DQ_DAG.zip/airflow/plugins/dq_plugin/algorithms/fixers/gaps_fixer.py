import pandas as pd
from dq_plugin.algorithms.reports.reports import GapsCheckerReport


def fix_gaps(dataframe: pd.DataFrame, report: GapsCheckerReport) -> pd.DataFrame:
    """
    Functions fixes gaps.
    :param dataframe: dataframe
    :param report: report of explored dataframe
    :return: fixed dataframe
    """

    fixed_dataframe = pd.DataFrame({'input_value': []})

    timestamp = report.get_start_timestamp()
    end_timestamp = report.get_end_timestamp()
    timedelta = report.get_timedelta()

    while timestamp <= end_timestamp:
        if timestamp in dataframe.index:
            fixed_dataframe.loc[timestamp] = dataframe.loc[timestamp]
        else:
            fixed_dataframe.loc[timestamp] = None
        timestamp += timedelta

    for gap in report.get_gaps():
        if gap.is_shifted():
            fixed_dataframe.loc[gap.get_timestamp()] = dataframe.loc[gap.get_fit_timestamp()]

    fixed_dataframe.interpolate(inplace=True)

    return fixed_dataframe


def main():
    from dq_plugin.algorithms.checkers.gaps_checker import find_gaps
    from dq_plugin.utils.dataframe_operations import normalize_dataframe

    df = normalize_dataframe(pd.read_csv('../../../../../local/csv/gaps.csv',
                                         delimiter=',', index_col='ds'))
    df_timedelta = pd.to_timedelta('01:00:00')

    print('searching gaps')
    report = find_gaps(df, df_timedelta)

    print('fixing gaps')
    fixed_df = fix_gaps(df, report)
    print(fixed_df)


if __name__ == '__main__':
    main()
