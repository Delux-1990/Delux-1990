import pandas as pd
from dq_plugin.algorithms.reports.reports import DataFromFutureCheckerReport


def fix_data_from_future(dataframe: pd.DataFrame, report: DataFromFutureCheckerReport) -> pd.DataFrame:
    """
    Functions remove data from future.
    :param dataframe: dataframe
    :param report: report of explored dataframe
    :return: fixed dataframe
    """
    if report.get_future_points_count() > 0:
        return dataframe.copy()[:report.get_future_points_timestamps()[0]].iloc[:-1]
    else:
        return dataframe.copy()


def main():
    from dq_plugin.algorithms.checkers.data_from_future_checker import find_data_from_future
    from dq_plugin.utils.dataframe_operations import normalize_dataframe

    df = normalize_dataframe(pd.read_csv('../../../../../local/csv/data_from_future.csv',
                                         delimiter=',', index_col='ds'))
    df_timedelta = pd.to_timedelta('01:00:00')

    print('searching data from future')
    report = find_data_from_future(df, df_timedelta, is_forecast=False)

    print('fixing data from future')
    fixed_df = fix_data_from_future(df, report)
    print(fixed_df)


if __name__ == '__main__':
    main()
