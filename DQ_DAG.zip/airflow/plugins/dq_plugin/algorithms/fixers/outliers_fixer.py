import pandas as pd
from dq_plugin.algorithms.reports.reports import OutliersCheckerReport


def fix_outliers(dataframe: pd.DataFrame, report: OutliersCheckerReport, method: str) -> pd.DataFrame:
    """
    Functions fixes outliers.
    :param dataframe: dataframe
    :param report: report of explored dataframe
    :param method: used to specify how to deal with outliers values. Possible values: 'previous', 'linear'.
    :return: fixed dataframe
    """

    fixed_dataframe = dataframe.copy(deep=True)

    for outlier in report.get_outliers():
        if method == 'previous':
            new_value = outlier.get_previous_value()
        else:
            new_value = (outlier.get_next_value() + outlier.get_previous_value()) / 2

        fixed_dataframe.loc[outlier.get_timestamp()] = new_value

    return fixed_dataframe


def main():
    from dq_plugin.algorithms.checkers.outliers_checker import find_outliers
    from dq_plugin.utils.dataframe_operations import normalize_dataframe
    import dq_plugin.utils.visualizer as vsl

    df = normalize_dataframe(pd.read_csv('../../../../../local/csv/smart_meter_gas_consumption.csv',
                                         delimiter=',', index_col='ds'))
    df_timedelta = pd.to_timedelta('00:05:00')

    print('searching outliers')
    report = find_outliers(df, df_timedelta)

    print('fixing outliers')
    fixed_df = fix_outliers(df, report, 'linear')
    vsl.show(fixed_df.index, fixed_df['input_value'])


if __name__ == '__main__':
    main()
