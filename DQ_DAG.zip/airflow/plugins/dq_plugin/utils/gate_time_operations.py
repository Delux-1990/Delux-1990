import pandas as pd


def convert_interval_to_timedelta(interval: int) -> pd.Timedelta:
    return pd.to_timedelta(interval, unit='s')
