import pandas as pd


def normalize_dataframe(dataframe: pd.DataFrame) -> pd.DataFrame:
    dataframe_copy = dataframe.copy(deep=True)

    dataframe_copy = dataframe_copy[~dataframe_copy.index.duplicated(keep='first')]
    dataframe_copy.index = pd.to_datetime(dataframe_copy.index, utc=True, infer_datetime_format=True)
    dataframe_copy['input_value'] = pd.to_numeric(dataframe_copy['input_value'], errors='coerce')
    dataframe_copy.sort_index(ascending=True, inplace=True)

    return dataframe_copy


def check_dataframe_normalization(dataframe):
    expected_dataframe_type = pd.DataFrame
    expected_dataframe_index_type = pd.DatetimeIndex
    expected_dataframe_timestamp_type = 'datetime64[ns, UTC]'
    expected_dataframe_value_type = 'float64'

    is_ok = True

    if not isinstance(dataframe, expected_dataframe_type):
        is_ok = False
        print(f"wrong dataframe type:\n"
              f"Expected {expected_dataframe_type}, got {type(dataframe)}")
    if not isinstance(dataframe.index, expected_dataframe_index_type):
        is_ok = False
        print(f"wrong dataframe index type:\n"
              f"Expected {expected_dataframe_index_type}, got {type(dataframe.index)}")
    if dataframe.index.dtype != expected_dataframe_timestamp_type:
        is_ok = False
        print(f"wrong dataframe timestamps type:\n"
              f"Expected {expected_dataframe_timestamp_type}, got {type(dataframe.index)}")
    if dataframe['input_value'].dtype != expected_dataframe_value_type:
        is_ok = False
        print(f"wrong dataframe values type:\n"
              f"Expected {expected_dataframe_value_type}, got {dataframe['input_value'].dtype}")

    if is_ok:
        print('Success')
