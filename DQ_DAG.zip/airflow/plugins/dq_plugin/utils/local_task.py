from dq_plugin.models import ACTIONS

# entire building (8 inputs)
data_source_configuration_1 = {
    'cug_guid': 'f07f1fd9-86b7-404c-a0b0-f4f5f964c482',     # BLIQ – 500 houses simulation PoQ
    'buildings_guids': [
        '871b5be2-cb80-40da-994a-c381feeda258'  # 3vpc0d9k
    ],
    'measurements_guids': [],
    'inputs_guids': []
}

# one measurement (1 input)
data_source_configuration_2 = {
    'cug_guid': 'f07f1fd9-86b7-404c-a0b0-f4f5f964c482',     # BLIQ – 500 houses simulation PoQ
    'buildings_guids': [
        '871b5be2-cb80-40da-994a-c381feeda258'  # 3vpc0d9k
    ],
    'measurements_guids': [
        '0260db13-8c3b-4ced-a571-397f7c224410'  # solar_dependencies.P1.active_energy.export
    ],
    'inputs_guids': []
}

data_source_configuration_3 = {
    'cug_guid': 'f07f1fd9-86b7-404c-a0b0-f4f5f964c482',     # BLIQ – 500 houses simulation PoQ
    'buildings_guids': [
        "871b5be2-cb80-40da-994a-c381feeda258",
        "a784df38-58df-41b5-8816-2747f7d2d036",
        "96d4e484-92e4-4599-bd89-5a9f62abbf4b",
        "e9b618fd-26ea-4ecb-a039-b4637f7f4aab",
        "452b441d-7685-4b31-b8cd-b6ab6876ea9d",
    ],
    'measurements_guids': [],
    'inputs_guids': []
}

data_source_configuration_4 = {
    'cug_guid': 'cfffae8e-7d37-4061-bc7d-54a637544da5',     # Eemnes
    'buildings_guids': [
        'feb4089f-717d-4284-bdc3-4218ea9ed313'              # Eemnes - Community Building
    ],
    'measurements_guids': [
        '635a0866-25af-48d4-b771-ea150e4000f7'              # Gas Consumption
    ],
    'inputs_guids': []
}

actions_configuration = [
    ACTIONS['Data from future detection'],
    ACTIONS['Gaps detection'],
    ACTIONS['Outliers detection'],
    ACTIONS['Anomalies detection'],
    ACTIONS['Input type classifying'],
    ACTIONS['Input profile classifying']
]

daterange_configuration = {
    'timestamp_from': '2020-01-01T00:00:00',
    'timestamp_to': '2023-01-01T00:00:00'
}

task_to_process = {
    'id': 1,
    'to_cleanse': False,
    'endpoint': 'https://example.ru',
    'data_source_configuration': data_source_configuration_4,
    'actions_configuration': actions_configuration,
    'daterange_configuration': daterange_configuration
}
