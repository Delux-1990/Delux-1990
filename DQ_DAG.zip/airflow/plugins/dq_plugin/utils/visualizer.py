import plotly.graph_objects as go


def show(x, y, name='base', mode='lines'):
    """
    Function shows plot in specified mode
    :param x: x-collection
    :param y: y-collection
    :param name: displayed plot name
    :param mode: mode of plot render: 'markers', 'lines' or 'lines+markers'
    """
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=x, y=y, mode=mode, name=name))
    fig.show()


def show_with_overlay(x_base, y_base, x_overlay, y_overlay,
                      base_name='base', overlay_name='overlay',
                      base_mode='lines', overlay_mode='markers') -> None:
    """
    Function shows base plot and overlays another plot on it
    :param x_base: x-collection for base plot
    :param y_base: y-collection for base plot
    :param x_overlay: x-collection for overlaid plot
    :param y_overlay: y-collection for overlaid plot
    :param base_name: displayed name for base plot
    :param overlay_name: displayed name for overlaid plot
    :param base_mode: mode of base plot render: 'markers', 'lines' or 'lines+markers'
    :param overlay_mode: mode of overlaid plot render: 'markers', 'lines' or 'lines+markers'
    """
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=x_base, y=y_base, mode=base_mode, name=base_name))
    fig.add_trace(go.Scatter(x=x_overlay, y=y_overlay, mode=overlay_mode, name=overlay_name))
    fig.show()


def show_with_vertical_lines(x_base, y_base, x_line, base_name='base', base_mode='lines') -> None:
    """
    Function shows base plot and overlays another plot on it
    :param x_base: x-collection for base plot
    :param y_base: y-collection for base plot
    :param x_line: x-collection for lines
    :param base_name: displayed name for base plot
    :param base_mode: mode of base plot render: 'markers', 'lines' or 'lines+markers'
    """
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=x_base, y=y_base, mode=base_mode, name=base_name))
    for x in x_line:
        fig.add_vline(x)
    fig.show()

