import io
import pandas as pd
import sqlalchemy as sa
from airflow.providers.postgres.hooks.postgres import PostgresHook
from dq_plugin.utils.dataframe_operations import normalize_dataframe


def save_df_to_db(connection_id: str, table_name: str, table_to_save: pd.DataFrame):
    engine = PostgresHook(connection_id).get_sqlalchemy_engine()
    conn = engine.raw_connection()
    cur = conn.cursor()
    output = io.StringIO()
    table_to_save.to_csv(output, sep='\t', header=False, index=False)
    output.seek(0)
    output.getvalue()
    cur.copy_from(output, table_name, null='')
    conn.commit()


def save_input_values_to_db(connection_id: str, table_name: str, df: pd.DataFrame, input_guid: str) -> None:
    """
    Function saves dataframe with values of input to database
    :param connection_id: connection string to establish connection with database
    :param table_name: name of the table where storage of inputs values is expected
    :param df: dataframe to be saved
    :param input_guid: guid of input which values you are going to save
    """
    df_with_input_guid = pd.DataFrame(
        {
            'ds': df.index,
            'input_value': df['input_value'],
            'input_guid': input_guid,
        }
    )
    save_df_to_db(connection_id, table_name, df_with_input_guid)


def get_input_values_from_db(connection_id: str, table_name: str, input_guid: str) -> pd.DataFrame:
    """
    Function loads values of specified input to dataframe and return it as result
    :param connection_id: connection string to establish connection with database
    :param table_name: name of the table where storage of inputs values is expected
    :param input_guid: guid of input which values you need to load
    :return: pd.DataFrame which contains dates in index column and input values in 'input_value' column
    """
    engine = PostgresHook(connection_id).get_sqlalchemy_engine()
    inputs_table = sa.Table(table_name, sa.MetaData(), autoload_with=engine)

    query = sa.select([inputs_table.c.ds, inputs_table.c.input_value]).where(inputs_table.c.input_guid == input_guid)
    df = pd.read_sql_query(query, engine, index_col='ds')

    return normalize_dataframe(df)


def update_input_values_in_db(connection_id: str, table_name: str, df: pd.DataFrame, input_guid: str) -> None:
    """
    Function updates values which belong input with specified guid on new values from specified dataframe
    :param connection_id: connection string to establish connection with database
    :param table_name: name of the table where storage of inputs values is expected
    :param df: dataframe with updated values
    :param input_guid: guid of input which values you are going to update
    """
    engine = PostgresHook(connection_id).get_sqlalchemy_engine()
    inputs_table = sa.Table(table_name, sa.MetaData(), autoload_with=engine)
    sa.delete(inputs_table).where(inputs_table.c.input_guid == input_guid)

    df_with_input_guid = pd.DataFrame(
        {
            'ds': df.index,
            'input_value': df['input_value'],
            'input_guid': input_guid,
        }
    )
    save_df_to_db(connection_id, table_name, df_with_input_guid)
