CREATE DATABASE mlp_airflow;
CREATE DATABASE mlp_mlflow;
CREATE DATABASE mlp_superset;
CREATE DATABASE mlp_forecasts;
